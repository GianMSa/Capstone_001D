import { InicioFormulario } from "../../components/inicio_sesion/InicioSesionTemplate";
export function InicioS() {
    return(<InicioFormulario/>);
}